import { motion } from 'motion/react';
import { Play, Eye, Heart } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function Works() {
  const works = [
    {
      id: 1,
      title: '星辰之恋',
      category: '言情漫剧',
      views: '8520万',
      likes: '126万',
      image: 'https://images.unsplash.com/photo-1705831156575-a5294d295a31?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYW5nYSUyMGNvbWljJTIwYXJ0d29yayUyMHZpYnJhbnR8ZW58MXx8fHwxNzcxOTA2OTExfDA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      id: 2,
      title: '都市修仙传',
      category: '玄幻漫剧',
      views: '1.2亿',
      likes: '280万',
      image: 'https://images.unsplash.com/photo-1741746239350-9021ddfa3d59?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhdGl2ZSUyMHN0dWRpbyUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzcxOTA2OTExfDA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      id: 3,
      title: '重生豪门',
      category: '都市漫剧',
      views: '9800万',
      likes: '195万',
      image: 'https://images.unsplash.com/photo-1764601841403-5c43713923c7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwYXJ0JTIwY3JlYXRpb24lMjBzY2VuZXxlbnwxfHx8fDE3NzE5MDY5MTF8MA&ixlib=rb-4.1.0&q=80&w=1080'
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-gray-900 to-gray-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-block px-4 py-2 bg-pink-500/20 backdrop-blur-sm rounded-full border border-pink-400/30 mb-6">
            <span className="text-sm text-pink-300">精品案例</span>
          </div>
          <h2 className="text-4xl font-bold text-white mb-4">
            爆款漫剧，从这里诞生
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            数千部优质作品见证平台实力，每一帧都是精心打造
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {works.map((work, index) => (
            <motion.div
              key={work.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="group relative cursor-pointer"
            >
              <div className="relative overflow-hidden rounded-2xl bg-gray-800 shadow-2xl">
                {/* Image */}
                <div className="aspect-[3/4] relative overflow-hidden">
                  <ImageWithFallback
                    src={work.image}
                    alt={work.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  
                  {/* Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-60 group-hover:opacity-80 transition-opacity"></div>
                  
                  {/* Play button */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-16 h-16 rounded-full bg-white/90 flex items-center justify-center backdrop-blur-sm">
                      <Play className="w-8 h-8 text-gray-900 fill-gray-900 ml-1" />
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <div className="mb-2">
                    <span className="inline-block px-3 py-1 bg-purple-500/80 backdrop-blur-sm rounded-full text-xs text-white">
                      {work.category}
                    </span>
                  </div>
                  
                  <h3 className="text-xl font-bold text-white mb-3">
                    {work.title}
                  </h3>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-300">
                    <div className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      <span>{work.views}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Heart className="w-4 h-4" />
                      <span>{work.likes}</span>
                    </div>
                  </div>
                </div>

                {/* Border glow effect */}
                <div className="absolute inset-0 rounded-2xl border-2 border-transparent group-hover:border-purple-500/50 transition-colors"></div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* View more button */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center mt-12"
        >
          <button className="px-8 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full transition-all hover:shadow-lg hover:shadow-purple-500/50">
            查看更多作品
          </button>
        </motion.div>
      </div>
    </section>
  );
}
