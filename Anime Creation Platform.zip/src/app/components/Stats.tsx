import { motion } from 'motion/react';
import { TrendingUp, Users, PlayCircle, Film } from 'lucide-react';

export function Stats() {
  const stats = [
    {
      icon: PlayCircle,
      value: '50亿+',
      label: '累计播放量',
      color: 'from-purple-500 to-pink-500'
    },
    {
      icon: Film,
      value: '10万+',
      label: '漫剧作品',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Users,
      value: '5万+',
      label: '创作者',
      color: 'from-green-500 to-emerald-500'
    },
    {
      icon: TrendingUp,
      value: '95%',
      label: '客户满意度',
      color: 'from-orange-500 to-yellow-500'
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-gray-900 to-gray-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-white mb-4">
            值得信赖的创作平台
          </h2>
          <p className="text-gray-400 text-lg">
            数据见证我们的成长与实力
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ scale: 1.05, y: -5 }}
              className="relative group"
            >
              <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl p-8 border border-gray-700 hover:border-gray-600 transition-all shadow-xl">
                {/* Icon */}
                <div className={`inline-flex p-4 rounded-xl bg-gradient-to-br ${stat.color} mb-4`}>
                  <stat.icon className="w-8 h-8 text-white" />
                </div>

                {/* Value */}
                <div className="text-4xl font-bold text-white mb-2">
                  {stat.value}
                </div>

                {/* Label */}
                <div className="text-gray-400">
                  {stat.label}
                </div>

                {/* Glow effect on hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-10 rounded-2xl transition-opacity`}></div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
