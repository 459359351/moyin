import { motion } from 'motion/react';
import { FileText, Users as UsersIcon, Camera, Layers, Clapperboard, Sparkles } from 'lucide-react';

export function Features() {
  const features = [
    {
      icon: FileText,
      title: '剧本解析',
      description: '智能解析剧本结构，自动提取关键信息，快速生成分镜脚本',
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      icon: UsersIcon,
      title: '角色一致性',
      description: 'AI 驱动的角色形象管理，确保全剧角色外观统一协调',
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Camera,
      title: '多视角场景',
      description: '支持多机位、多角度场景生成，丰富画面表现力',
      gradient: 'from-green-500 to-emerald-500'
    },
    {
      icon: Layers,
      title: '专业分镜系统',
      description: '影视级分镜编辑工具，精准控制每一帧画面',
      gradient: 'from-orange-500 to-yellow-500'
    },
    {
      icon: Clapperboard,
      title: '统筹式导演',
      description: 'AI 导演系统协调全局，把控节奏与情感表达',
      gradient: 'from-red-500 to-pink-500'
    },
    {
      icon: Sparkles,
      title: 'S级成片',
      description: '全流程批量化生产，输出影视工业级高质量作品',
      gradient: 'from-indigo-500 to-purple-500'
    }
  ];

  return (
    <section className="py-20 bg-gray-950 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden opacity-20">
        <div className="absolute w-96 h-96 bg-purple-500 rounded-full blur-3xl" style={{ top: '-10%', left: '-5%' }}></div>
        <div className="absolute w-96 h-96 bg-blue-500 rounded-full blur-3xl" style={{ bottom: '-10%', right: '-5%' }}></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-block px-4 py-2 bg-purple-500/20 backdrop-blur-sm rounded-full border border-purple-400/30 mb-6">
            <span className="text-sm text-purple-300">核心功能</span>
          </div>
          <h2 className="text-4xl font-bold text-white mb-4">
            AI 驱动的全流程创作
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            从创意到成片，Mopian Creator 为您提供专业的漫剧创作解决方案
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="group relative"
            >
              <div className="h-full bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700 hover:border-gray-600 transition-all">
                {/* Icon with gradient background */}
                <div className={`inline-flex p-4 rounded-xl bg-gradient-to-br ${feature.gradient} mb-6 group-hover:scale-110 transition-transform`}>
                  <feature.icon className="w-8 h-8 text-white" />
                </div>

                {/* Title */}
                <h3 className="text-xl font-bold text-white mb-3">
                  {feature.title}
                </h3>

                {/* Description */}
                <p className="text-gray-400 leading-relaxed">
                  {feature.description}
                </p>

                {/* Hover effect */}
                <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-5 rounded-2xl transition-opacity`}></div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
