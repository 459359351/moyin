import { motion } from "motion/react";
import { ArrowRight, Sparkles } from "lucide-react";
import { Button } from "./ui/button";

export function CTA() {
  return (
    <section className="py-20 bg-gradient-to-br from-purple-900 via-pink-900 to-indigo-900 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden opacity-30">
        <motion.div
          className="absolute w-96 h-96 bg-white rounded-full blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.1, 0.2, 0.1],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          style={{
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
          }}
        />
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full border border-white/20 mb-8">
            <Sparkles className="w-4 h-4 text-purple-300" />
            <span className="text-sm text-white">
              立即体验 AI 漫剧创作
            </span>
          </div>

          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            开启您的漫剧创作之旅
          </h2>

          <p className="text-xl text-gray-200 mb-10 max-w-2xl mx-auto">
            加入数万创作者的行列，用 AI 技术让创意变为现实
            <br />
            现在注册，即可获得 100 积分免费额度
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              size="lg"
              className="bg-white text-purple-900 hover:bg-gray-100 px-8 py-6 text-lg font-semibold group"
            >
              免费开始创作
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-white/5 border-white text-white hover:bg-white/10 px-8 py-6 text-lg"
            >
              联系销售团队
            </Button>
          </div>

          <p className="text-sm text-gray-300 mt-6">
            无需信用卡 · 随时取消 · 7x24 技术支持
          </p>
        </motion.div>
      </div>
    </section>
  );
}