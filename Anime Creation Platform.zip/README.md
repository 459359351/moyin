
  # Anime Creation Platform

  This is a code bundle for Anime Creation Platform. The original project is available at https://www.figma.com/design/eWlcktQkHmo02876Hs5UwE/Anime-Creation-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  